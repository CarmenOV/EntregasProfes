
    
function cambiarTema() {
    var body = document.getElementById("body");
    var a = document.getElementById("a");
    var h1 = document.getElementById("h1");
    var p1 = document.getElementById("p1");
    var p2 = document.getElementById("p2");
    var p3 = document.getElementById("p3");
    var p4 = document.getElementById("p4");


    body.style.backgroundColor = "white";
    p4.style.border = "none";
    p4.style.backgroundColor = "white";


    a.style.border = "none";
    a.style.backgroundColor = "white";
    a.style.color = "blue";
    a.style.textDecoration = "none";

}

function cambiarTema2() {
    var body = document.getElementById("body");
    var a = document.getElementById("a");
    var h1 = document.getElementById("h1");
    var p1 = document.getElementById("p1");
    var p2 = document.getElementById("p2");
    var p3 = document.getElementById("p3");
    var p4 = document.getElementById("p4");


    body.style.backgroundColor = "lightyellow";

    a.style.border = "1px solid";
    a.style.backgroundColor = "lightblue";
    a.style.color = "blue";
    a.style.fontFamily = "verdana";
    a.style.fontSize = "20px";
    a.style.textDecoration = "none";


    h1.style.color = "black";
    h1.style.text = "bold";
    p3.style.text = "bold";
    p3.style.color = "black";

    p4.style.border = "1px solid";
    p4.style.backgroundColor = "yellow";




}

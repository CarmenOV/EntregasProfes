function areaRectangulo() {
    var lado1 = prompt("Introduce la longitud del primer lado del rectángulo:");
    var lado2 =prompt("Introduce la longitud del segundo lado del rectángulo:");

    // Calcular el área
    var area = lado1 * lado2;

    // Mostrar el resultado en un alert
    alert("El área del rectángulo es: " + area);
}